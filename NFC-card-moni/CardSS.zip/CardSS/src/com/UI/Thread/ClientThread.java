package com.UI.Thread;

import android.util.Log;

import com.example.ui.NetProceesFlag;
import com.util.Msg;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ClientThread extends Thread
{
  Msg msg;

  public ClientThread(Msg paramMsg)
  {
    this.msg = paramMsg;
  }

  public void run()
  {
    super.run();
    Log.i("falg", "new Socket to 123.207.158.123");
    Socket localSocket;
    ObjectOutputStream localObjectOutputStream;
    ObjectInputStream localObjectInputStream;
    try
    {
      localSocket = new Socket("123.207.158.123", 33445);
      Log.i("falg", "Socket to 10.139.38.237  suc");
      localObjectOutputStream = new ObjectOutputStream(localSocket.getOutputStream());
      localObjectInputStream = new ObjectInputStream(localSocket.getInputStream());
      Log.i("flag", "ObjectStream: type" + this.msg.getMsgType());
      localObjectOutputStream.writeObject(this.msg);
      localObjectOutputStream.flush();
      try {
		this.msg = ((Msg)localObjectInputStream.readObject());
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
      localObjectOutputStream.close();
      localObjectInputStream.close();
      localSocket.close();
      
      
    }
    catch (IOException localIOException)
    {
      
    }
    
    NetProceesFlag.isprocessover = true;
    NetProceesFlag.returntype=msg.getMsgType();
    NetProceesFlag.message=msg;
  }
}