package com.util;

public class Person
{
 
  private String studentID = null;  //1
  private String password = null;   //2
  private String name = null;       //3
  private String profecialty = null;//4
  private String banji = null;      //5
  private String colleage = null;   //6
  private String number = null;     //7
  private String QQ = null;     //8
  private String email = null;     //9
  private String signword = null;     //10
  private boolean autoLogin = false;
  private float jine;

  
  
  


public float getJine() {
	return jine;
}

public void setJine(float jine) {
	this.jine = jine;
}

public String getQQ() {
	return QQ;
}

public void setQQ(String qQ) {
	QQ = qQ;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public String getSignword() {
	return signword;
}

public void setSignword(String signword) {
	this.signword = signword;
}

public String getBanji()
  {
    return this.banji;
  }

  public String getColleage()
  {
    return this.colleage;
  }

  public String getName()
  {
    return this.name;
  }

  public String getNumber()
  {
    return this.number;
  }

  public String getPassword()
  {
    return this.password;
  }

  public String getProfecialty()
  {
    return this.profecialty;
  }

  public String getStudentID()
  {
    return this.studentID;
  }

  public boolean isAutoLogin()
  {
    return this.autoLogin;
  }

  public void setAutoLogin(boolean paramBoolean)
  {
    this.autoLogin = paramBoolean;
  }

  public void setBanji(String paramString)
  {
    this.banji = paramString;
  }

  public void setColleage(String paramString)
  {
    this.colleage = paramString;
  }

  public void setName(String paramString)
  {
    this.name = paramString;
  }

  public void setNumber(String paramString)
  {
    this.number = paramString;
  }

  public void setPassword(String paramString)
  {
    this.password = paramString;
  }

  public void setProfecialty(String paramString)
  {
    this.profecialty = paramString;
  }

  public void setStudentID(String paramString)
  {
    this.studentID = paramString;
  }

@Override
public String toString() {
	return "Person [studentID=" + studentID + ", password=" + password
			+ ", name=" + name + ", profecialty=" + profecialty + ", banji="
			+ banji + ", colleage=" + colleage + ", number=" + number + ", QQ="
			+ QQ + ", email=" + email + ", signword=" + signword
			+ ", autoLogin=" + autoLogin + ", jine=" + jine + "]";
}

public Person(String studentID, String password, String name,
		String profecialty, String banji, String colleage, String number,
		String qQ, String email, String signword, boolean autoLogin, float jine) {
	super();
	this.studentID = studentID;
	this.password = password;
	this.name = name;
	this.profecialty = profecialty;
	this.banji = banji;
	this.colleage = colleage;
	this.number = number;
	QQ = qQ;
	this.email = email;
	this.signword = signword;
	this.autoLogin = autoLogin;
	this.jine = jine;
}


  
}