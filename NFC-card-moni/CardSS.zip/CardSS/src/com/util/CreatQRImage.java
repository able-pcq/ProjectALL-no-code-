package com.util;

import java.util.Hashtable;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

import android.graphics.Bitmap;

public class CreatQRImage {
	public static Bitmap getImage(String tt,int width,int high){
		QRCodeWriter writer = new QRCodeWriter();
		try {
			BitMatrix martix = writer.encode(tt, BarcodeFormat.QR_CODE,width, high);
		} catch (WriterException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Hashtable<EncodeHintType, String> hints = new Hashtable<EncodeHintType, String>();
		hints.put(EncodeHintType.CHARACTER_SET, "utf-8");
		BitMatrix bitMatrix = null;
		try {
			bitMatrix = new QRCodeWriter().encode(tt,BarcodeFormat.QR_CODE, width, high, hints);
		} catch (WriterException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int[] pixels = new int[width * high];
		
		for (int y = 0; y < high; y++) {
			for (int x = 0; x < width; x++) {
			if (bitMatrix.get(x, y)) {
			pixels[y * width + x] = 0xff000000;
			} else {
			  pixels[y * high + x] = 0xffffffff;
			  }
		    }
		}
		Bitmap bitmap = Bitmap.createBitmap(width, high,Bitmap.Config.ARGB_8888);
		bitmap.setPixels(pixels, 0, width, 0, 0, width, high);

		return bitmap;
		
	}
	
	
	

}
