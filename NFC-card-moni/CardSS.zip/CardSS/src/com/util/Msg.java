package com.util;

import java.io.Serializable;

public class Msg  implements Serializable
{
  private static final long serialVersionUID = 1L;
  private String studentID = null;  //1
  private String password = null;   //2
  private String name = null;       //3
  private String profecialty = null;//4
  private String banji = null;      //5
  private String colleage = null;   //6
  private String number = null;     //7
  private String QQ = null;     //8
  private String email = null;     //9
  private String signword = null;     //10
  private int msgType;//1ע�ᣬ2��½
  
  private float jine;
  
 
  
public float getJine() {
	return jine;
}
public void setJine(float jine) {
	this.jine = jine;
}
public int getMsgType() {
	return msgType;
}
public void setMsgType(int msgType) {
	this.msgType = msgType;
}
public String getStudentID() {
	return studentID;
}
public void setStudentID(String studentID) {
	this.studentID = studentID;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getProfecialty() {
	return profecialty;
}
public void setProfecialty(String profecialty) {
	this.profecialty = profecialty;
}
public String getBanji() {
	return banji;
}
public void setBanji(String banji) {
	this.banji = banji;
}
public String getColleage() {
	return colleage;
}
public void setColleage(String colleage) {
	this.colleage = colleage;
}
public String getNumber() {
	return number;
}
public void setNumber(String number) {
	this.number = number;
}
public String getQQ() {
	return QQ;
}
public void setQQ(String qQ) {
	QQ = qQ;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getSignword() {
	return signword;
}
public void setSignword(String signword) {
	this.signword = signword;
}
public Msg(String studentID, String password, String name, String profecialty,
		String banji, String colleage, String number, String qQ, String email,
		String signword, int msgType, float jine) {
	super();
	this.studentID = studentID;
	this.password = password;
	this.name = name;
	this.profecialty = profecialty;
	this.banji = banji;
	this.colleage = colleage;
	this.number = number;
	QQ = qQ;
	this.email = email;
	this.signword = signword;
	this.msgType = msgType;
	this.jine = jine;
}


@Override
public String toString() {
	return "Msg [studentID=" + studentID + ", password=" + password + ", name="
			+ name + ", profecialty=" + profecialty + ", banji=" + banji
			+ ", colleage=" + colleage + ", number=" + number + ", QQ=" + QQ
			+ ", email=" + email + ", signword=" + signword + ", msgType="
			+ msgType + ", jine=" + jine + "]";
}




  
}