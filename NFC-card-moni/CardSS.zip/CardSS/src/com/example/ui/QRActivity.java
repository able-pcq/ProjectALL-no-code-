package com.example.ui;
import com.example.cardss.R;
import com.util.CreatQRImage;
import com.util.Person;
import com.util.QRCodeUtil;

import android.app.ActionBar;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import android.widget.TextView;

public class QRActivity extends Activity{
	TextView qr_tx_name,qr_tx_xuehao;
	ImageView qr_im_qr;
	Person person;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_qr);
		
		initView();
		
		
		
		ActionBar actionBar=getActionBar();
        actionBar.setDisplayShowHomeEnabled(false);
        actionBar.setDisplayHomeAsUpEnabled(true);//��ʾ���ذ�ť
//        actionBar.setHomeButtonEnabled(true);

        actionBar.setTitle("�ҵĶ�ά��");
		
		person=Tool.readData(this);
		qr_tx_name.setText(person.getName());
		qr_tx_xuehao.setText(person.getStudentID());
		
		//she
		
		show();
	}
	
	
	
	@Override
    public boolean onOptionsItemSelected(MenuItem item) {
    	// TODO Auto-generated method stub
    	if(item.getItemId() == android.R.id.home)
        {
            finish();
            return true;
        }
    	return super.onOptionsItemSelected(item);
    }
	

	private void show() {
		// TODO Auto-generated method stub
		int width=qr_im_qr.getWidth();
		int high=qr_im_qr.getHeight();
		
		
		String tt="ѧ�ţ�"+person.getStudentID()+"--������"+person.getName()+"--��"+person.getJine();
//		Bitmap logo= BitmapFactory.decodeResource(this.getBaseContext().getResources(), R.drawable.touxiang);
//		Bitmap qrmap=QRCodeUtil.createImage(tt,250,250, logo);
		qr_im_qr.setImageBitmap(CreatQRImage.getImage(tt, 250, 250));
		
		Log.i("flag", width+" + "+high);
	}

	private void initView() {
		// TODO Auto-generated method stub
		qr_tx_xuehao=(TextView) findViewById(R.id.qr_tx_xuehao);
		qr_tx_name=(TextView) findViewById(R.id.qr_tx_name);
		
		qr_im_qr=(ImageView) findViewById(R.id.qr_im_qr);
		
	}

}
