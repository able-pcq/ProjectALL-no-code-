package com.example.ui;

import android.content.Context;
import android.content.SharedPreferences;
import com.util.Person;

public class Tool
{
  public static Person readData(Context paramContext)
  {
    Person localPerson = new Person("", "", "", "", "", "", "", "", "", "", false, 0);
    SharedPreferences localSharedPreferences = paramContext.getSharedPreferences("info", 1);
    String str1 = localSharedPreferences.getString("studentID", "");
    String str2 = localSharedPreferences.getString("password", "");
    String str3 = localSharedPreferences.getString("name", "");
    String str4 = localSharedPreferences.getString("profecialty", "");
    String str5 = localSharedPreferences.getString("banji", "");
    String str6 = localSharedPreferences.getString("colleage", "");
    String str7 = localSharedPreferences.getString("number", "");
    String str8 = localSharedPreferences.getString("QQ", "");
    String str9 = localSharedPreferences.getString("email", "");
    String str10 = localSharedPreferences.getString("signword", "");
    float money=localSharedPreferences.getFloat("money", 0);
    
    localPerson.setAutoLogin(localSharedPreferences.getBoolean("autologin", false));
    localPerson.setStudentID(str1);
    localPerson.setPassword(str2);
    localPerson.setName(str3);
    localPerson.setBanji(str5);
    localPerson.setProfecialty(str4);
    localPerson.setColleage(str6);
    localPerson.setNumber(str7);
    localPerson.setQQ(str8);
    localPerson.setEmail(str9);
    localPerson.setSignword(str10);
    localPerson.setJine(money);
    
    return localPerson;
  }

  public static boolean writeAutoLogin(Context paramContext, boolean paramBoolean)
  {
    SharedPreferences.Editor localEditor = paramContext.getSharedPreferences("info", 2).edit();
    localEditor.putBoolean("autologin", paramBoolean);
    localEditor.commit();
    return true;
  }
  
  public static boolean writeStudentID(Context paramContext, String stuID)
  {
    SharedPreferences.Editor localEditor = paramContext.getSharedPreferences("info", 2).edit();
    localEditor.putString("studentID", stuID);
    localEditor.commit();
    return true;
  }
  
  public static boolean writePassword(Context paramContext, String password)
  {
    SharedPreferences.Editor localEditor = paramContext.getSharedPreferences("info", 2).edit();
    localEditor.putString("password", password);
    localEditor.commit();
    return true;
  }
  
  
  
  
  

  public static boolean writeData(Context paramContext, Person paramPerson)
  {
    SharedPreferences.Editor localEditor = paramContext.getSharedPreferences("info", 2).edit();
    
    localEditor.putString("studentID", paramPerson.getStudentID());
    localEditor.putString("password", paramPerson.getPassword());
    localEditor.putString("name", paramPerson.getName());    
    localEditor.putString("profecialty", paramPerson.getProfecialty());
    localEditor.putString("banji", paramPerson.getBanji());
    localEditor.putString("colleage", paramPerson.getColleage());   
    localEditor.putString("number", paramPerson.getNumber());
    localEditor.putString("QQ", paramPerson.getQQ());
    localEditor.putString("email", paramPerson.getEmail());
    localEditor.putString("signword", paramPerson.getSignword());
    localEditor.putBoolean("autologin", paramPerson.isAutoLogin());
    localEditor.putFloat("money", paramPerson.getJine());
    localEditor.commit();
    return true;
  }
}