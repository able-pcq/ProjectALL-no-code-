package com.example.ui;

import com.example.cardss.R;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;


public class MainActivity extends Activity implements OnClickListener {
	View im_bt_moni,im_bt_erweima,im_bt_showinfo,im_bt_setting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        
        ExitApplication.getInstance().addActivity(this);
        
        ActionBar actionBar=getActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);//��ʾ���ذ�ť
        actionBar.setDisplayShowHomeEnabled(false);
        actionBar.setTitle("��ģ��ϵͳ");
        
        initView();
        

    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
    	// TODO Auto-generated method stub
    	if(item.getItemId() == android.R.id.home)
        {
            finish();
            return true;
        }
    	return super.onOptionsItemSelected(item);
    }
    
    
    
    
    

	private void initView() {
		// TODO Auto-generated method stub
		im_bt_moni=findViewById(R.id.im_bt_moni);
        im_bt_erweima=findViewById(R.id.im_bt_erweima);
        im_bt_showinfo=findViewById(R.id.im_bt_showinfo);
        im_bt_setting=findViewById(R.id.im_bt_setting);
        im_bt_moni.setOnClickListener(this);
        im_bt_erweima.setOnClickListener(this);
        im_bt_showinfo.setOnClickListener(this);
        im_bt_setting.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.im_bt_moni:
			switchToMoni();
			break;
		case R.id.im_bt_erweima:
			switchToQR();
			break;
		case R.id.im_bt_showinfo:
			switchToMyinfo();
			break;
		case R.id.im_bt_setting:
			switchToSetting();
			break;

		default:
			break;
		}
	}

	private void switchToMoni() {
		// TODO Auto-generated method stub
		Intent localIntent = new Intent(MainActivity.this, com.example.android.cardemulation.MainActivity.class);
		MainActivity.this.startActivity(localIntent);
	}

	private void switchToSetting() {
		// TODO Auto-generated method stub
		Intent localIntent = new Intent(MainActivity.this, SettingActivity.class);
		MainActivity.this.startActivity(localIntent);
	}

	private void switchToMyinfo() {
		// TODO Auto-generated method stub
		Intent localIntent = new Intent(MainActivity.this, ShowInfoActivity.class);
		MainActivity.this.startActivity(localIntent);
	}

	private void switchToQR() {
		// TODO Auto-gene
		Intent localIntent = new Intent(MainActivity.this, QRActivity.class);
		MainActivity.this.startActivity(localIntent);
	}

    
}
