package com.example.ui;

import com.example.cardss.R;

import android.app.Dialog;
import android.content.Context;
import android.view.View;

public class AboutDialog extends Dialog{

	public AboutDialog(Context context) {
		super(context);
		
		final View view = getLayoutInflater().inflate(R.layout.about,   
                null);
		setContentView(view);
        //setButton(R.string.ok, (OnClickListener) null);   
        //setIcon(R.drawable.about);   
        setTitle("Version:   v1.2.1" );   
        //setView(view); 
	}
	

}
