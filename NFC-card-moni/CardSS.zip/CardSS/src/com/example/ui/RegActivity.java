package com.example.ui;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.UI.Thread.ClientThread;
import com.example.cardss.R;
import com.util.Msg;
import com.util.Person;

public class RegActivity extends Activity  implements OnClickListener{
  Button RegButton;
  EditText et_reg_ID;
  EditText et_reg_number;
  EditText et_reg_password;
  EditText et_reg_password2;
  Handler handler;
  Msg message = null;
  
  
  @Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_reg);
		
		 ActionBar actionBar=getActionBar();
         actionBar.setDisplayShowHomeEnabled(false);
         actionBar.setDisplayHomeAsUpEnabled(true);//��ʾ���ذ�ť
//         actionBar.setHomeButtonEnabled(true);

         actionBar.setTitle("ע��");
		
		init();
		
		//message=new Msg(studentID, password, name, profecialty, banji, colleage, number, qQ, email, signword, msgType, jine)
		message=new Msg("", "", "", "", "", "", "", "", "", "", 2, 0);
		handler = new myHandler();
	
	}
  
  
  
  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
  	// TODO Auto-generated method stub
  	if(item.getItemId() == android.R.id.home)
      {
          finish();
          return true;
      }
  	return super.onOptionsItemSelected(item);
  }
  
  
  

  private void init()
  {
    this.et_reg_ID = ((EditText)findViewById(R.id.reg_et_studentID));
    this.et_reg_password = ((EditText)findViewById(R.id.reg_et_password));
    this.et_reg_password2 = ((EditText)findViewById(R.id.reg_et_password_two));
    this.et_reg_number = ((EditText)findViewById(R.id.reg_et_phone));
    this.RegButton = ((Button)findViewById(R.id.reg_bt_reg));
    this.et_reg_ID.setOnClickListener(this);
    this.et_reg_password.setOnClickListener(this);
    this.et_reg_password2.setOnClickListener(this);
    this.et_reg_number.setOnClickListener(this);
    this.RegButton.setOnClickListener(this);
  }

  private void tryReg()
  {
    String str1 = this.et_reg_ID.getText().toString().trim();
    String str2 = this.et_reg_password.getText().toString().trim();
    String str3 = this.et_reg_password2.getText().toString().trim();
    String str4 = this.et_reg_number.getText().toString().trim();
    Log.i("flag", "studentID:" + str1 + "password:" + str2 + "password2:" + str3 + "number:" + str4);
    if ((str2.equals(str3)) && (str2 != null) && (str3 != null))
    {
      if ((str1.equals("")) || (str1 == null) || (str2.equals("")) || (str2 == null) || (str4.equals("")) || (str4 == null))
      {
        Toast.makeText(this, "�������ݲ���Ϊ��", Toast.LENGTH_SHORT).show();
      }
      this.message.setStudentID(str1);
      this.message.setPassword(str2);
      this.message.setNumber(str4);
      new helpThread().start();
      return;
    }
    Toast.makeText(this, "�������벻һ��", Toast.LENGTH_SHORT).show();
  }


  
  
  

  class helpThread extends Thread
  {
    int a;

    public void run()
    {
      Log.i("flag", "helpThread:--" + Thread.currentThread().getName());
      super.run();
      new ClientThread(RegActivity.this.message).start();
      Log.i("flag", "try");
      Message localMessage = RegActivity.this.handler.obtainMessage();
      
      while (!NetProceesFlag.isprocessover)
      {
      	try {
				sleep(10);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
      }
      NetProceesFlag.isprocessover = false;
      Log.i("flag", "suc");
      localMessage.what = 4568;
      localMessage.arg1=NetProceesFlag.returntype;
      handler.sendMessage(localMessage);
    }
  }

  class myHandler extends Handler
  {
    public void handleMessage(Message paramMessage)
    {
      if (paramMessage.what == 4568)
      {
    	  switch (paramMessage.arg1) {
		case 202:
			Toast.makeText(RegActivity.this, "ע��ɹ�", 1).show();
			
			
			//ע��ʱĬ��100��
//	        new Person(studentID, password, name, profecialty, banji, colleage, number, qQ, email, signword, autoLogin, jine)
	        Tool.writeData(RegActivity.this, new Person(message.getStudentID(), message.getPassword(), "", "", "", "", message.getNumber(), "", "", "", false, 100));
	        Intent localIntent = new Intent(RegActivity.this, LoginActivity.class);
	        RegActivity.this.startActivity(localIntent);
	        RegActivity.this.finish();
			break;
		case 201:
			Toast.makeText(RegActivity.this, "�û��Ѿ�����", 1).show();
			break;
		case 203:
			Toast.makeText(RegActivity.this, "ע��ʧ��", 1).show();
			break;

		default:
			Toast.makeText(RegActivity.this, "�볢����ϵ����Ա�Ƿ���������", 1).show();
			break;
		}
    	  
    	  
        
      }
      super.handleMessage(paramMessage);
    }
  }

@Override
public void onClick(View v) {
	// TODO Auto-generated method stub
	switch (v.getId()) {
	case R.id.reg_bt_reg:
		tryReg();
		break;

	default:
		break;
	}
}


}