package com.example.ui;

import com.example.cardss.R;
import com.util.Person;

import android.app.ActionBar;
import android.app.Activity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;

public class ShowInfoActivity extends Activity{
	EditText et_studentID,et_name,et_profecialty,et_banji,et_xueyuan,et_phone,et_QQ,et_email,et_signword,et_money;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_info_show);
		
		ActionBar actionBar=getActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);//��ʾ���ذ�ť
        actionBar.setDisplayShowHomeEnabled(false);
        actionBar.setTitle("������Ϣ");
        
        Person person=Tool.readData(this);
        
        init();
        initView(person);
	}
	
	
	
	private void initView(Person person) {
		// TODO Auto-generated method stub
		et_studentID.setText(person.getStudentID());
		et_name.setText(person.getName());
		et_profecialty.setText(person.getProfecialty());
		et_banji.setText(person.getBanji());
		et_xueyuan.setText(person.getColleage());
		et_phone.setText(person.getNumber());
		et_QQ.setText(person.getQQ());
		et_email.setText(person.getEmail());
		et_signword.setText(person.getSignword());
		et_money.setText("��: "+person.getJine()+"Ԫ");
	}



	private void init() {
		// TODO Auto-generated method stub
		et_studentID=(EditText) findViewById(R.id.show_et_studentID);
		et_name=(EditText) findViewById(R.id.show_et_name);
		et_profecialty=(EditText) findViewById(R.id.show_et_profecialty);
		et_banji=(EditText) findViewById(R.id.show_et_banji);
		et_xueyuan=(EditText) findViewById(R.id.show_et_xueyuan);
		et_phone=(EditText) findViewById(R.id.show_et_phone);
		et_QQ=(EditText) findViewById(R.id.show_et_QQ);
		et_email=(EditText) findViewById(R.id.show_et_email);
		et_signword=(EditText) findViewById(R.id.show_et_signword);
		et_money=(EditText) findViewById(R.id.show_et_money);
	}



	@Override
	  public boolean onOptionsItemSelected(MenuItem item) {
	  	// TODO Auto-generated method stub
	  	if(item.getItemId() == android.R.id.home)
	      {
	          finish();
	          return true;
	      }
	  	return super.onOptionsItemSelected(item);
	  }

}
