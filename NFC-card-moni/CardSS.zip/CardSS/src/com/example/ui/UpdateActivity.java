package com.example.ui;

import com.UI.Thread.ClientThread;
import com.example.cardss.R;
import com.example.ui.LoginActivity.myHandler;
import com.util.Msg;
import com.util.Person;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateActivity extends Activity implements OnClickListener {
	EditText et_studentID,et_name,et_specialty,et_banji,et_xueyuan,et_phone,et_QQ,et_email,et_signword;
	Button bt_update_info;
	Msg message = null;
	Handler handler;
	//���ϵ���
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_changeinfo);
		init();
		
		ActionBar actionBar=getActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);//��ʾ���ذ�ť
        actionBar.setDisplayShowHomeEnabled(false);
        actionBar.setTitle("���Ƹ�����Ϣ");
		
        
        handler = new myHandler();
        
	}
	
	
	
	
	@Override
	  public boolean onOptionsItemSelected(MenuItem item) {
	  	// TODO Auto-generated method stub
	  	if(item.getItemId() == android.R.id.home)
	      {
	          finish();
	          return true;
	      }
	  	return super.onOptionsItemSelected(item);
	  }

	private void init() {
		// TODO Auto-generated method stub
		et_studentID=(EditText) findViewById(R.id.up_et_studentID);
		et_name=(EditText) findViewById(R.id.up_et_name);
		et_specialty=(EditText) findViewById(R.id.up_et_profecialty);
		et_banji=(EditText) findViewById(R.id.up_et_banji);
		et_xueyuan=(EditText) findViewById(R.id.up_et_xueyuan);
		et_phone=(EditText) findViewById(R.id.up_et_phone);
		et_QQ=(EditText) findViewById(R.id.up_et_QQ);
		et_email=(EditText) findViewById(R.id.up_et_email);
		et_signword=(EditText) findViewById(R.id.up_et_signword);
		bt_update_info=(Button) findViewById(R.id.up_bt_update);
		bt_update_info.setOnClickListener(this);
		
		Person person=Tool.readData(UpdateActivity.this);
		et_studentID.setText(person.getStudentID());
		et_name.setText(person.getName());
		et_specialty.setText(person.getProfecialty());
		et_banji.setText(person.getBanji());
		et_xueyuan.setText(person.getColleage());
		et_phone.setText(person.getNumber());
		et_QQ.setText(person.getQQ());
		et_email.setText(person.getEmail());
		et_signword.setText(person.getSignword());
		
		
		message=new Msg(person.getStudentID(), person.getPassword(), "", "", "", "", "", "", "", "", 3, 0);

	}




	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.up_bt_update:
			tryUpdateInfo();
			break;

		default:
			break;
		}
		
	}


//  ����+д�뱾��
//������Ϣ  ����+д�뱾��
	private void tryUpdateInfo() {
		// TODO Auto-generated method stub
//		String banji,xueyuan,phone,QQ,email,signword;
//		banji=et_banji.getText().toString().trim();
//		xueyuan=et_xueyuan.getText().toString().trim();
//		phone=et_phone.getText().toString().trim();
//		QQ=et_QQ.getText().toString().trim();
//		email=et_email.getText().toString().trim();
//		signword=et_signword.getText().toString().trim();
//		
		message.setName(et_name.getText().toString().trim());
		message.setProfecialty(et_specialty.getText().toString().trim());
		message.setBanji(et_banji.getText().toString().trim());
		message.setColleage(et_xueyuan.getText().toString().trim());
		message.setNumber(et_phone.getText().toString().trim());
		message.setQQ(et_QQ.getText().toString().trim());
		message.setEmail(et_email.getText().toString().trim());
		message.setSignword(et_signword.getText().toString().trim());
		
		new helpThread().start();
	
	}
	
	
	
	class helpThread extends Thread
    {
      int a;

      public void run()
      {
        Log.i("flag", "helpThread:--" + Thread.currentThread().getName());
        super.run();
        new ClientThread(message).start();
        Message localMessage = UpdateActivity.this.handler.obtainMessage();
        while (!NetProceesFlag.isprocessover)
        {
        	try {
				sleep(10);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
        NetProceesFlag.isprocessover = false;
        localMessage.what = 4569;
        localMessage.arg1=NetProceesFlag.returntype;
        handler.sendMessage(localMessage);
        
        
      }
    }
    
    class myHandler extends Handler
    {
      public void handleMessage(Message paramMessage)
      {
        if (paramMessage.what == 4569)
        {
        	//���߷��������ص����ͽ��б�д
        	switch (paramMessage.arg1) {
			case 302:
				  Toast.makeText(UpdateActivity.this, "���³ɹ�", 1).show();
				  
				  Msg msgg=NetProceesFlag.message;
				  Person oldP=Tool.readData(UpdateActivity.this);
				  Tool.writeData(UpdateActivity.this, new Person(msgg.getStudentID(), msgg.getPassword(), msgg.getName(), msgg.getProfecialty(), msgg.getBanji(), msgg.getColleage(), msgg.getNumber(), msgg.getQQ(), msgg.getEmail(), msgg.getSignword(), oldP.isAutoLogin(), msgg.getJine()));
				break;

			case 303:
				Toast.makeText(UpdateActivity.this, "δ֪����", 1).show();
				break;
			default:
				Toast.makeText(UpdateActivity.this, "�볢����ϵ����Ա�Ƿ���������", 1).show();
				break;
			}
         
        }
        super.handleMessage(paramMessage);
      }
    }

}
