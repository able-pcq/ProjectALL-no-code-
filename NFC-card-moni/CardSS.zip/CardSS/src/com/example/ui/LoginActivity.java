package com.example.ui;

import com.UI.Thread.ClientThread;
import com.example.cardss.R;
import com.other.lock.LockActivity;
import com.other.lock.PreferenceUtil;
import com.util.Msg;
import com.util.Person;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;



public class LoginActivity extends Activity implements OnClickListener {
  CheckBox cb_atuologin;
  EditText et_loginID;
  EditText et_loginpassword;
  Handler handler;
  Button loginButton;
  Msg message = null;
  TextView tx_forget_password;
  TextView tx_reg;
  
  @Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		
		ExitApplication.getInstance().addActivity(this);
		
		
		ActionBar actionBar=getActionBar();
		actionBar.setDisplayShowHomeEnabled(false);
		actionBar.hide();
		
		init();
		
		
	    Person localPerson = Tool.readData(this);
	    uiInit(localPerson);
	    
	    message=new Msg(localPerson.getStudentID(), localPerson.getPassword(), "", "", "", "", "", "", "", "", 1, 0);
	    
	    
	    this.handler = new myHandler();
	    
	    
	    
	    
	    
	    
	    SharedPreferences preferences = getSharedPreferences(com.other.lock.MainActivity.LOCK, MODE_PRIVATE);
        String lockPattenString = preferences.getString(com.other.lock.MainActivity.LOCK_KEY, null);

        
        if (lockPattenString != null) {
            Intent intent = new Intent(this, LockActivity.class);
            startActivity(intent);

        }else{
        	NetProceesFlag.cantryLogin=true;
        	
        	
        	
	     
        }
	    
        if(NetProceesFlag.cantryLogin){
        	if ((localPerson.isAutoLogin())){
    		    Login();
        	}
        }
	    
        
		
		
	}

  	@Override
  	public void onClick(View v) {
	
  		switch (v.getId())
  	    {
  	    case R.id.bt_login:
  	    	Login();
  	    	break;
  	    case R.id.tx_login_toreg:
  	    	swithReg();
  	        break;
  	    case R.id.tx_forget_password:
  	    	forgetPassword();
  	    	break;
  	    default:
  	    	break;
  	      
  	      }
  	}
  	
  	
  	
  	

  	private void forgetPassword() {
		// TODO Auto-generated method stub
  		Intent localIntent = new Intent(LoginActivity.this, FindpasswordActivity.class);
        LoginActivity.this.startActivity(localIntent);
	}

	private void swithReg()
    {
      startActivity(new Intent(this, RegActivity.class));
    }
	
	
	private void init()
    {
      this.et_loginID = ((EditText)findViewById(R.id.et_login_studengtID));
      this.et_loginpassword = ((EditText)findViewById(R.id.et_login_password));
      this.loginButton = ((Button)findViewById(R.id.bt_login));
      this.tx_forget_password = ((TextView)findViewById(R.id.tx_forget_password));
      this.tx_reg = ((TextView)findViewById(R.id.tx_login_toreg));
      this.cb_atuologin = ((CheckBox)findViewById(R.id.cb_login_auto));
      this.loginButton.setOnClickListener(this);
      this.tx_forget_password.setOnClickListener(this);
      this.tx_reg.setOnClickListener(this);
    }
  	
  	 private void uiInit(Person paramPerson)
  	  {
  	    this.et_loginID.setText(paramPerson.getStudentID());
  	    this.et_loginpassword.setText(paramPerson.getPassword());
  	    this.cb_atuologin.setChecked(paramPerson.isAutoLogin());
  	  }
  	 
  	private void Login()
    {
      String str1 = this.et_loginID.getText().toString();
      String str2 = this.et_loginpassword.getText().toString();
      if ((str1.equals("")) || (str1 == null) || (str2.equals("")) || (str2 == null))
      {
        Toast.makeText(this, "�������ݲ���Ϊ��", 1).show();
        return;
      }
      this.message.setStudentID(str1);
      this.message.setPassword(str2);
      new helpThread().start();
    }
  	
    class helpThread extends Thread
    {
      int a;

      public void run()
      {
        Log.i("flag", "helpThread:--" + Thread.currentThread().getName());
        super.run();
        new ClientThread(LoginActivity.this.message).start();
        Message localMessage = LoginActivity.this.handler.obtainMessage();
        while (!NetProceesFlag.isprocessover)
        {
        	try {
				sleep(10);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
        NetProceesFlag.isprocessover = false;
        localMessage.what = 4567;
        localMessage.arg1=NetProceesFlag.returntype;
        LoginActivity.this.handler.sendMessage(localMessage);
        
        
      }
    }
    
    class myHandler extends Handler
    {
      public void handleMessage(Message paramMessage)
      {
        if (paramMessage.what == 4567)
        {
        	Log.i("flag", NetProceesFlag.message.toString());
        	//���߷��������ص����ͽ��б�д
        	switch (paramMessage.arg1) {
			case 101:
				  Toast.makeText(LoginActivity.this, "��¼�ɹ�", 1).show();
				  
				  Msg msgg=NetProceesFlag.message;
				  Tool.writeData(LoginActivity.this, new Person(msgg.getStudentID(), msgg.getPassword(), msgg.getName(), msgg.getProfecialty(), msgg.getBanji(), msgg.getColleage(), msgg.getNumber(), msgg.getQQ(), msgg.getEmail(), msgg.getSignword(), cb_atuologin.isChecked(), msgg.getJine()));
				  Tool.writeAutoLogin(LoginActivity.this, LoginActivity.this.cb_atuologin.isChecked());
		          Intent localIntent = new Intent(LoginActivity.this, MainActivity.class);
		          LoginActivity.this.startActivity(localIntent);
		          
		          LoginActivity.this.finish();//�����˽���
				break;

			case 102:
				Toast.makeText(LoginActivity.this, "�������", 1).show();
				break;
			case 103:
				Toast.makeText(LoginActivity.this, "�û�������", 1).show();
				break;
			case 104:
				Toast.makeText(LoginActivity.this, "������δ֪����", 1).show();
				break;
				
			default:
				Toast.makeText(LoginActivity.this, "�볢����ϵ����Ա�Ƿ���������", 1).show();
				break;
			}
         
        }
        super.handleMessage(paramMessage);
      }
    }



  
}