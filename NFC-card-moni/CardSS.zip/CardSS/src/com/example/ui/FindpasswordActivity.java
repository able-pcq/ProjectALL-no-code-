package com.example.ui;

import com.example.cardss.R;

import android.app.ActionBar;
import android.app.Activity;
import android.os.Bundle;
import android.view.MenuItem;

public class FindpasswordActivity extends Activity{
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_find_password);
		
		
		ActionBar actionBar=getActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);//��ʾ���ذ�ť
        actionBar.setDisplayShowHomeEnabled(false);
        actionBar.setTitle("�һ�����");
	}
	
	@Override
    public boolean onOptionsItemSelected(MenuItem item) {
    	// TODO Auto-generated method stub
    	if(item.getItemId() == android.R.id.home)
        {
            finish();
            return true;
        }
    	return super.onOptionsItemSelected(item);
    }

}
