package com.example.ui;

import com.example.cardss.R;
import com.example.ui.SwitchButton.OnChangeListener;
import com.other.lock.LockActivity;
import com.other.lock.LockSetupActivity;
import com.other.lock.PreferenceUtil;
import android.app.ActionBar;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class SettingActivity extends Activity implements OnClickListener {
	View layout_accountmanager,layout_updateinfo,layout_lock,layout_about;
	Button bt_signout;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_setting);
		init();
		
		ActionBar actionBar=getActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);//��ʾ���ذ�ť
        actionBar.setDisplayShowHomeEnabled(false);
        actionBar.setTitle("����");
        
        
        
        
        
       
        boolean ishavepassword=false;
        
        SharedPreferences preferences = getSharedPreferences(com.other.lock.MainActivity.LOCK, MODE_PRIVATE);
        String lockPattenString = preferences.getString(com.other.lock.MainActivity.LOCK_KEY, null);

        if (lockPattenString != null) {
            ishavepassword=true;
        }
        
        
        final SwitchButton sb = (SwitchButton) findViewById(R.id.wiperSwitch1);
        sb.setFlage(ishavepassword);
        Log.i("flag", "ishavepassword��"+ishavepassword);
        
        sb.setOnChangeListener(new OnChangeListener() {  
              
            @Override  
            public void onChange(SwitchButton sb, boolean state) {  
                // TODO Auto-generated method stub  
                Log.d("switchButton", state ? "��":"��");  
//                Toast.makeText(SettingActivity.this, state ? "��":"��", Toast.LENGTH_SHORT).show(); 
                
                if(sb.getFlage()){
                	tryAddLock();
                	Log.i("flag", "tryAddLock();");
                }else{
                	tryColseLock();
                	Log.i("flag", "tryColseLock();");
                }
                
            }

			private void tryColseLock() {
				// TODO Auto-generated method stub
//				String Gespassword = PreferenceUtil.getGesturePassword(SettingActivity.this);
				
				SharedPreferences preferences2 = getSharedPreferences(com.other.lock.MainActivity.LOCK, MODE_PRIVATE);
		        String Gespassword = preferences2.getString(com.other.lock.MainActivity.LOCK_KEY, null);
				
				
				
				if(Gespassword==null){
//					Toast.makeText(SettingActivity.this, "δ������������", Toast.LENGTH_SHORT).show();
				}else{
					//�Ѿ������룬��֤����ȥ����----��������״̬���ɸ���
					
					//�����������ʾ���Ե�����
					NetProceesFlag.iscomefromCloseGesPassword=true;
					startActivity(new Intent(SettingActivity.this,LockActivity.class));
					
					sb.setFlage(true);
				}
			}

			private void tryAddLock() {
				// TODO Auto-generated method stub
				SharedPreferences preferences2 = getSharedPreferences(com.other.lock.MainActivity.LOCK, MODE_PRIVATE);
		        String Gespassword = preferences2.getString(com.other.lock.MainActivity.LOCK_KEY, null);
				//����û������,ȥ��������
				if(Gespassword==null){
					startActivity(new Intent(SettingActivity.this,LockSetupActivity.class));
//					Toast.makeText(SettingActivity.this, "û���������룬��������", Toast.LENGTH_SHORT).show();
				}else{
//					Toast.makeText(SettingActivity.this, "���������Ѿ�����", Toast.LENGTH_SHORT).show();
				}
				
				
			}  
        });
        
        
        
        
        
	}
	
	@Override
	  public boolean onOptionsItemSelected(MenuItem item) {
	  	// TODO Auto-generated method stub
	  	if(item.getItemId() == android.R.id.home)
	      {
	          finish();
	          return true;
	      }
	  	return super.onOptionsItemSelected(item);
	  }
	
	
	
	

	private void init() {
		// TODO Auto-generated method stub
		layout_accountmanager=findViewById(R.id.setting_layout_accountmanager);
		layout_updateinfo=findViewById(R.id.setting_layout_updateinfo);
		layout_lock=findViewById(R.id.setting_layout_lock);
		layout_about=findViewById(R.id.setting_layout_about);
		bt_signout=(Button) findViewById(R.id.setting_bt_signout);
		layout_accountmanager.setOnClickListener(this);
		layout_updateinfo.setOnClickListener(this);
		layout_lock.setOnClickListener(this);
		layout_about.setOnClickListener(this);
		bt_signout.setOnClickListener(this);
		
	}

	
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.setting_layout_accountmanager:
			//
			accountManager();
			break;
		case R.id.setting_layout_updateinfo:
			//
			SwitchtoUpdate();
			break;
		case R.id.setting_layout_lock:
			//
			AddLock();
			break;
		case R.id.setting_layout_about:
			//
			showAbout();
			break;
		case R.id.setting_bt_signout:
			//
			signOut();
			break;

		default:
			break;
		}
	}

	
	
	private void signOut() {
		// TODO Auto-generated method stub
		ExitApplication.getInstance().exit();
	}

	private void showAbout() {
		// TODO Auto-generated method stub
		new AboutDialog(this).show();
	}

	private void AddLock() {
		// TODO Auto-generated method stub
		
	}

	private void accountManager() {
		// TODO Auto-generated method stub
		new AlertDialog.Builder(SettingActivity.this).setTitle("ϵͳ��ʾ")//���öԻ������  
		  
	     .setMessage("�Ƿ�ע����ǰ�˺ţ�")//������ʾ������  	  
	     .setPositiveButton("ȷ��",new DialogInterface.OnClickListener() {//����ȷ����ť             
	  
	         @Override  
	  
	         public void onClick(DialogInterface dialog, int which) {//ȷ����ť����Ӧ�¼�  
	  
	             // TODO Auto-generated method stub  
	  
//	             finish();  
	             Tool.writeAutoLogin(SettingActivity.this, false);
	  
	         }  
	  
	     }).setNegativeButton("ȡ��",new DialogInterface.OnClickListener() {//���ӷ��ذ�ť  

	         @Override  
	  
	         public void onClick(DialogInterface dialog, int which) {//��Ӧ�¼�  
	  
	             // TODO Auto-generated method stub  
	  
//	            Log.i("alertdialog"," �뱣�����ݣ�");  
	  
	         }  
	  
	     }).show();//�ڰ�����Ӧ�¼�����ʾ�˶Ի��� 
	}

	private void SwitchtoUpdate() {
		// TODO Auto-generated method stub
		startActivity(new Intent(SettingActivity.this, UpdateActivity.class));
	}

}
